// lib/oracle/sql/LDB_Query.ts

export function sql_LDB_recon_221(hasAccount: boolean) {
  return `
    SELECT FN.DATE_TIME,
           FN.WITHDRAW,        FN.DEPOSIT,
           FN.SOKXAY_REWARD,   FN.SOKXAY_BONUS,
           FN.SCN_REWARD,      FN.SOKXAY_SPIN,
           FN.SOKXAY_TAX_REWARD,
           FN.FTR_DR,          FN.FTR_CR,
           FN.BANK_FEE,        FN.THE_OTHER,
           FN.WITHDRAW - (FN.SOKXAY_REWARD + FN.SOKXAY_BONUS + FN.SCN_REWARD
                          + FN.SOKXAY_SPIN + FN.FTR_DR + FN.BANK_FEE)      AS DIFF_DR,
           FN.DEPOSIT  - (FN.SOKXAY_TAX_REWARD + FN.FTR_CR)                AS DIFF_CR
    FROM (
        SELECT
            TO_CHAR(DATE_TIME, 'YYYY-MM-DD')                                          AS DATE_TIME,
            SUM(WITHDRAW)                                                              AS WITHDRAW,
            SUM(DEPOSIT)                                                               AS DEPOSIT,
            SUM(CASE WHEN TXN_TYPE = 'SOKXAY_REWARD'     THEN WITHDRAW ELSE 0 END)   AS SOKXAY_REWARD,
            SUM(CASE WHEN TXN_TYPE = 'SOKXAY_BONUS'      THEN WITHDRAW ELSE 0 END)   AS SOKXAY_BONUS,
            SUM(CASE WHEN TXN_TYPE = 'SCN_REWARD'        THEN WITHDRAW ELSE 0 END)   AS SCN_REWARD,
            SUM(CASE WHEN TXN_TYPE = 'SOKXAY_SPIN'       THEN WITHDRAW ELSE 0 END)   AS SOKXAY_SPIN,
            SUM(CASE WHEN TXN_TYPE = 'SOKXAY_TAX_REWARD' THEN DEPOSIT  ELSE 0 END)   AS SOKXAY_TAX_REWARD,
            SUM(CASE WHEN TXN_TYPE = 'FTR'               THEN WITHDRAW ELSE 0 END)   AS FTR_DR,
            SUM(CASE WHEN TXN_TYPE = 'FTR'               THEN DEPOSIT  ELSE 0 END)   AS FTR_CR,
            SUM(CASE WHEN TXN_TYPE IN (
                'FTR_FEE','LDB_FEE_REWARD_FTR','LDB_FEE_LOTTO_SELL',
                'LDB_FEE_ACCT','LDB_FEE_DEEPLINK'
            ) THEN WITHDRAW ELSE 0 END)        AS BANK_FEE,
            SUM(CASE WHEN TXN_TYPE NOT IN (
                'SOKXAY_REWARD','SOKXAY_BONUS','SCN_REWARD','SOKXAY_SPIN',
                'SOKXAY_TAX_REWARD','FTR','FTR_FEE','LDB_FEE_REWARD_FTR',
                'LDB_FEE_LOTTO_SELL','LDB_FEE_ACCT','LDB_FEE_DEEPLINK'
            ) THEN WITHDRAW ELSE 0 END)     AS THE_OTHER
        FROM LDB_STMT
        WHERE DATE_TIME >= TO_DATE(:dateFrom, 'YYYY-MM-DD')
          AND DATE_TIME  < TO_DATE(:dateTo,   'YYYY-MM-DD') + 1
          ${hasAccount ? "AND ACCT_NO = :account" : ""} 
          AND LDB_REF NOT IN (
          SELECT LDB_REF
          FROM LDB_STMT
          WHERE TXN_TYPE IN ( 'SOKXAY_REWARD','SOKXAY_BONUS','SCN_REWARD', 'SOKXAY_SPIN','SOKXAY_TAX_REWARD','FTR', 'FTR_FEE', 'LDB_FEE_REWARD_FTR','LDB_FEE_LOTTO_SELL', 'LDB_FEE_ACCT', 'LDB_FEE_DEEPLINK' )
          GROUP BY LDB_REF
          HAVING COUNT(*) > 1
             AND (SUM(WITHDRAW) - SUM(DEPOSIT)) = 0
      )
        GROUP BY TO_CHAR(DATE_TIME, 'YYYY-MM-DD')
    ) FN
    ORDER BY FN.DATE_TIME DESC`
}

export function sql_LDB_recon_944(hasAccount: boolean) {
  return `   
SELECT FN.DATE_TIME,  FN.WITHDRAW, FN.DEPOSIT,  FN.SOKXAY_REFUND,  FN.SCN_REFUND,  FN.SOKXAY_LOTTO_SETTLE_CR,  FN.SCN_LOTTO_SETTLE_CR, FN.FTR_DR, FN.FTR_CR, FN.BANK_FEE,  FN.THE_OTHER,
   
    FN.WITHDRAW - ( FN.SOKXAY_REFUND  + FN.SCN_REFUND  + FN.FTR_DR + FN.BANK_FEE )  AS DIFF_DR,

    FN.DEPOSIT - ( FN.SOKXAY_LOTTO_SETTLE_CR + FN.SCN_LOTTO_SETTLE_CR + FTR_CR )     AS DIFF_CR

FROM (
    SELECT
        TO_CHAR(DATE_TIME, 'YYYY-MM-DD')                                    AS DATE_TIME,
        SUM(WITHDRAW)                                                        AS WITHDRAW,
        SUM(DEPOSIT)                                                         AS DEPOSIT,

        SUM(CASE WHEN TXN_TYPE = 'SOKXAY_REFUND_LOTTO_SELL'   THEN WITHDRAW ELSE 0 END) AS SOKXAY_REFUND,
        SUM(CASE WHEN TXN_TYPE = 'SCN_REFUND_LOTTO_SELL'        THEN WITHDRAW ELSE 0 END) AS SCN_REFUND,
        SUM(CASE WHEN TXN_TYPE = 'SOKXAY_LOTTO_SETTLE_CR'          THEN DEPOSIT ELSE 0 END) AS SOKXAY_LOTTO_SETTLE_CR,
        SUM(CASE WHEN TXN_TYPE = 'SCN_LOTTO_SETTLE_CR'          THEN DEPOSIT ELSE 0 END) AS SCN_LOTTO_SETTLE_CR,
        SUM(CASE WHEN TXN_TYPE = 'FTR'                 THEN WITHDRAW ELSE 0 END) AS FTR_DR,
        SUM(CASE WHEN TXN_TYPE = 'FTR'                 THEN DEPOSIT  ELSE 0 END) AS FTR_CR,
        SUM(CASE WHEN TXN_TYPE IN ( 'FTR_FEE', 'LDB_FEE_ACCT' )  THEN WITHDRAW ELSE 0 END) AS BANK_FEE,
        SUM(CASE WHEN TXN_TYPE NOT IN ( 'SOKXAY_REFUND_LOTTO_SELL','SCN_REFUND_LOTTO_SELL','SOKXAY_LOTTO_SETTLE_CR','SCN_LOTTO_SETTLE_CR','FTR','FTR_FEE', 'LDB_FEE_ACCT' )  THEN (WITHDRAW + DEPOSIT) ELSE 0 END) AS THE_OTHER

    FROM LDB_STMT
    WHERE DATE_TIME >= TO_DATE(:dateFrom, 'YYYY-MM-DD')
      AND DATE_TIME  < TO_DATE(:dateTo,   'YYYY-MM-DD') + 1  
      ${hasAccount ? "AND ACCT_NO = :account" : ""}
     AND LDB_REF NOT IN (
          
          SELECT LDB_REF
          FROM LDB_STMT
           WHERE TXN_TYPE IN ( 'SOKXAY_REFUND_LOTTO_SELL','SCN_REFUND_LOTTO_SELL','SOKXAY_LOTTO_SETTLE_CR','SCN_LOTTO_SETTLE_CR','FTR','FTR_FEE', 'LDB_FEE_ACCT' )
          GROUP BY LDB_REF
          HAVING COUNT(*) > 1
             AND (SUM(WITHDRAW) - SUM(DEPOSIT)) = 0
      )
    GROUP BY TO_CHAR(DATE_TIME, 'YYYY-MM-DD')

) FN
ORDER BY FN.DATE_TIME DESC`}

export function sql_LDB_recon_2360020(hasAccount: boolean) {
  return `  
SELECT FN.DATE_TIME, FN.WITHDRAW, FN.SOKXAY_LOTTO_SELL, FN.SOKXAY_LOTTO_SETTLE_DR,  FN.BANK_FEE,  FN.THE_OTHER,
    FN.WITHDRAW - ( FN.SOKXAY_LOTTO_SETTLE_DR + FN.BANK_FEE )  AS DIFF_DR
FROM (
    SELECT
        TO_CHAR(DATE_TIME, 'YYYY-MM-DD')                                    AS DATE_TIME,
        SUM(WITHDRAW)                                                        AS WITHDRAW,
        SUM(DEPOSIT)                                                         AS DEPOSIT,

        SUM(CASE WHEN TXN_TYPE = 'SOKXAY_LOTTO_SELL'   THEN DEPOSIT ELSE 0 END) AS SOKXAY_LOTTO_SELL,
        SUM(CASE WHEN TXN_TYPE = 'SOKXAY_LOTTO_SETTLE_DR'        THEN WITHDRAW ELSE 0 END) AS SOKXAY_LOTTO_SETTLE_DR,
        SUM(CASE WHEN TXN_TYPE IN ( 'FTR_FEE', 'LDB_FEE_ACCT' )  THEN WITHDRAW ELSE 0 END) AS BANK_FEE,
        SUM(CASE WHEN TXN_TYPE NOT IN ('SOKXAY_LOTTO_SELL','SOKXAY_LOTTO_SETTLE_DR','FTR_FEE', 'LDB_FEE_ACCT')  THEN (WITHDRAW + DEPOSIT) ELSE 0 END) AS THE_OTHER

    FROM LDB_STMT
    WHERE DATE_TIME >= TO_DATE(:dateFrom, 'YYYY-MM-DD')
      AND DATE_TIME  < TO_DATE(:dateTo,   'YYYY-MM-DD') + 1  
        ${hasAccount ? "AND ACCT_NO = :account" : ""}
     AND LDB_REF NOT IN (
          SELECT LDB_REF
          FROM LDB_STMT
          WHERE TXN_TYPE IN ('SOKXAY_LOTTO_SELL','SOKXAY_LOTTO_SETTLE_DR','FTR_FEE', 'LDB_FEE_ACCT')
          GROUP BY LDB_REF
          HAVING COUNT(*) > 1
             AND (SUM(WITHDRAW) - SUM(DEPOSIT)) = 0
      )
    GROUP BY TO_CHAR(DATE_TIME, 'YYYY-MM-DD')

) FN
ORDER BY FN.DATE_TIME DESC
`}
export function sql_LDB_recon_3360020(hasAccount: boolean) {
  return `  
SELECT FN.DATE_TIME, FN.WITHDRAW, FN.SCN_LOTTO_SELL, FN.SCN_LOTTO_SETTLE_DR,  FN.BANK_FEE,  FN.THE_OTHER,
    FN.WITHDRAW - ( FN.SCN_LOTTO_SETTLE_DR + FN.BANK_FEE )  AS DIFF_DR
FROM (
    SELECT
        TO_CHAR(DATE_TIME, 'YYYY-MM-DD')                                    AS DATE_TIME,
        SUM(WITHDRAW)                                                        AS WITHDRAW,
        SUM(DEPOSIT)                                                         AS DEPOSIT,

        SUM(CASE WHEN TXN_TYPE = 'SCN_LOTTO_SELL'   THEN DEPOSIT ELSE 0 END) AS SCN_LOTTO_SELL,
        SUM(CASE WHEN TXN_TYPE = 'SCN_LOTTO_SETTLE_DR'        THEN WITHDRAW ELSE 0 END) AS SCN_LOTTO_SETTLE_DR,
        SUM(CASE WHEN TXN_TYPE IN ( 'FTR_FEE', 'LDB_FEE_ACCT' )  THEN WITHDRAW ELSE 0 END) AS BANK_FEE,
        SUM(CASE WHEN TXN_TYPE NOT IN ('SCN_LOTTO_SELL','SCN_LOTTO_SETTLE_DR','FTR_FEE', 'LDB_FEE_ACCT')  THEN (WITHDRAW + DEPOSIT) ELSE 0 END) AS THE_OTHER

    FROM LDB_STMT
    WHERE DATE_TIME >= TO_DATE(:dateFrom, 'YYYY-MM-DD')
      AND DATE_TIME  < TO_DATE(:dateTo,   'YYYY-MM-DD') + 1  
        ${hasAccount ? "AND ACCT_NO = :account" : ""}
     AND LDB_REF NOT IN (
          -- ตัด LDB_REF ที่มี Withdraw = Deposit ออก (ล้างกัน = ไม่ใช่ Real TXN)
          SELECT LDB_REF
          FROM LDB_STMT
          WHERE TXN_TYPE IN ('SCN_LOTTO_SELL','SCN_LOTTO_SETTLE_DR','FTR_FEE', 'LDB_FEE_ACCT')
          GROUP BY LDB_REF
          HAVING COUNT(*) > 1
             AND (SUM(WITHDRAW) - SUM(DEPOSIT)) = 0
      )
    GROUP BY TO_CHAR(DATE_TIME, 'YYYY-MM-DD')

) FN
ORDER BY FN.DATE_TIME DESC

`}


