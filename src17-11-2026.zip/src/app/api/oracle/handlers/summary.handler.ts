import { NextResponse } from "next/server";
import { VIEWS, ACCOUNTS } from "../config/constants";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type Conn = any;
// eslint-disable-next-line @typescript-eslint/no-explicit-any
type OPT = any;

export async function handleSellSummaryDrawIds(conn: Conn, OPT_OBJ: OPT) {
  const result = await conn.execute(
    `SELECT DISTINCT TO_NUMBER(DRAW_ID) AS DRAW_ID
     FROM   ECOMMERCE2026.LOTLINK_SELL_BY_USER
     WHERE  POS_ID = '080821001APP'
     ORDER  BY TO_NUMBER(DRAW_ID) DESC`,
    {},
    OPT_OBJ,
  );
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return NextResponse.json({
    rows: (result.rows ?? []).map((r: any) => ({ DRAW_ID: Number(r.DRAW_ID) })),
  });
}

export async function handleSellSummaryByDraw(
  conn: Conn,
  OPT_OBJ: OPT,
  params: URLSearchParams,
) {
  const drawFrom = params.get("draw_from") ?? "";
  const drawTo = params.get("draw_to") ?? "";
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const binds: Record<string, any> = {
    posId: "080821001APP",
    drawFrom: drawFrom ? Number(drawFrom) : null,
    drawTo: drawTo ? Number(drawTo) : null,
    jdbAcct: ACCOUNTS.JDB_3180,
    jdbTxnSell: "LOTTO_SELL",
    jdbDealerId: "080821001APP",
    ldbTxnSell: "SOKXAY_LOTTO_SELL",
  };

  const sql = `
    WITH
    lot AS (
      SELECT TO_NUMBER(DRAW_ID) AS DID,
             TO_CHAR(MAX(DRAW_DATE), 'DD/MM/YYYY') AS DRAW_DATE,
             SUM(SELL_TT) AS LOTLINK_TOTAL
      FROM   ECOMMERCE2026.LOTLINK_SELL_BY_USER
      WHERE  POS_ID = :posId
        AND  (:drawFrom IS NULL OR TO_NUMBER(DRAW_ID) >= :drawFrom)
        AND  (:drawTo   IS NULL OR TO_NUMBER(DRAW_ID) <= :drawTo)
      GROUP  BY DRAW_ID
    ),
    bcel AS (
      SELECT DRAW_ID AS DID,
             SUM(CASE WHEN NVL(POINT_CONSUMED, 0) = 0  THEN TOTALSALE      ELSE 0 END) AS BCEL_AMT,
             SUM(CASE WHEN NVL(POINT_CONSUMED, 0) > 0  THEN POINT_CONSUMED ELSE 0 END) AS POINT_AMT
      FROM   LOTTO_ORDER_BCEL@SPLUS_2026_DB
      WHERE  ORDER_STATUS = 'DONE'
        AND  (:drawFrom IS NULL OR DRAW_ID >= :drawFrom)
        AND  (:drawTo   IS NULL OR DRAW_ID <= :drawTo)
      GROUP  BY DRAW_ID
    ),
    scn AS (
      SELECT TO_NUMBER(DRAW_ID) AS DID,
             SUM(CASE WHEN PAYMENT_CHANNEL = 'BCEL'    THEN AMOUNT ELSE 0 END) AS SCN_BCEL,
             SUM(CASE WHEN PAYMENT_CHANNEL = 'LDB'     THEN AMOUNT ELSE 0 END) AS SCN_LDB,
             SUM(CASE WHEN PAYMENT_CHANNEL = 'M-Money' THEN AMOUNT ELSE 0 END) AS SCN_MMONEY
      FROM   ${VIEWS.SCN_PORTAL_DATA}
      WHERE  (:drawFrom IS NULL OR TO_NUMBER(DRAW_ID) >= :drawFrom)
        AND  (:drawTo   IS NULL OR TO_NUMBER(DRAW_ID) <= :drawTo)
        and  (QUOTA='SOKXAY' or QUOTA='SCN-XOKXAY')
      GROUP  BY DRAW_ID
    ),
    jdb AS (
      SELECT TO_NUMBER(a.DRAWID) AS DID,
             SUM(a.TOTALSALE) AS JDB_AMT
      FROM   ${VIEWS.LOTLINK_BILL} a
      WHERE  a.DEALERID = :jdbDealerId
        AND  LENGTH(a.CLIENTREFNO) < 25
        AND  EXISTS (
          SELECT 1
          FROM   ${VIEWS.JDB_STMT} s
          WHERE  s.BANK_ACCT = :jdbAcct AND s.TXN_TYPE = :jdbTxnSell
            AND  TO_CHAR(s.DRAWID) = TO_CHAR(a.DRAWID)
            AND  TO_CHAR(s.LOTTO_BILL_NO) = TO_CHAR(a.BILLNUMBER)
        )
        AND  (:drawFrom IS NULL OR TO_CHAR(a.DRAWID) >= TO_CHAR(:drawFrom))
        AND  (:drawTo   IS NULL OR TO_CHAR(a.DRAWID) <= TO_CHAR(:drawTo))
      GROUP  BY a.DRAWID
    ),
    ldb AS (
      SELECT TO_NUMBER(DRAWID) AS DID,
             SUM(ORIGINAL_BILL_AMT) AS LDB_AMT
      FROM   ${VIEWS.LDB_STMT}
      WHERE  TXN_TYPE IN (:ldbTxnSell)
        AND  LDB_TXN_ID NOT IN (
          SELECT LDB_TXN_ID
          FROM   ${VIEWS.LDB_STMT}
          WHERE  TXN_TYPE IN (:ldbTxnSell)
          GROUP  BY LDB_TXN_ID
          HAVING COUNT(*) > 1
             AND (SUM(DEPOSIT) - SUM(WITHDRAW)) = 0
        )
        AND  (:drawFrom IS NULL OR TO_CHAR(DRAWID) >= TO_CHAR(:drawFrom))
        AND  (:drawTo   IS NULL OR TO_CHAR(DRAWID) <= TO_CHAR(:drawTo))
      GROUP  BY DRAWID
    )
    SELECT l.DID AS DRAW_ID, l.DRAW_DATE, l.LOTLINK_TOTAL AS LOTLINK,
           NVL(b.BCEL_AMT, 0) AS BCEL, NVL(b.POINT_AMT, 0) AS POINT,
           NVL(s.SCN_BCEL, 0) AS SCN_BCEL, NVL(s.SCN_LDB, 0) AS SCN_LDB,
           NVL(s.SCN_MMONEY, 0) AS SCN_MMONEY,
           NVL(j.JDB_AMT, 0) AS JDB, NVL(d.LDB_AMT, 0) AS LDB,
           (NVL(b.BCEL_AMT,0)+NVL(b.POINT_AMT,0)+NVL(s.SCN_BCEL,0)+NVL(s.SCN_LDB,0)+NVL(s.SCN_MMONEY,0)+NVL(j.JDB_AMT,0)+NVL(d.LDB_AMT,0)) - l.LOTLINK_TOTAL AS DIFF
    FROM   lot l
    LEFT JOIN bcel b ON b.DID = l.DID
    LEFT JOIN scn  s ON s.DID = l.DID
    LEFT JOIN jdb  j ON j.DID = l.DID
    LEFT JOIN ldb  d ON d.DID = l.DID
    ORDER  BY l.DID ASC`;

  const result = await conn.execute(sql, binds, {
    ...OPT_OBJ,
    fetchArraySize: 500,
  });
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return NextResponse.json({
    rows: (result.rows ?? []).map((r: any) => ({
      DRAW_ID: Number(r.DRAW_ID),
      DRAW_DATE: String(r.DRAW_DATE ?? ""),
      LOTLINK: Number(r.LOTLINK ?? 0),
      BCEL: Number(r.BCEL ?? 0),
      POINT: Number(r.POINT ?? 0),
      SCN_BCEL: Number(r.SCN_BCEL ?? 0),
      SCN_LDB: Number(r.SCN_LDB ?? 0),
      SCN_MMONEY: Number(r.SCN_MMONEY ?? 0),
      JDB: Number(r.JDB ?? 0),
      LDB: Number(r.LDB ?? 0),
      DIFF: Number(r.DIFF ?? 0),
    })),
  });
}

export async function handleBcelOnepayReconByDraw(
  conn: Conn,
  OPT_OBJ: OPT,
  params: URLSearchParams,
) {
  const drawFrom = params.get("draw_from") ?? "";
  const drawTo = params.get("draw_to") ?? "";
  const dateFrom = params.get("date_from") ?? "";
  const dateTo = params.get("date_to") ?? "";

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const binds: Record<string, any> = {
    p_acct: ACCOUNTS.BCEL_ONEPAY,
    p_txn_type: "BCEL_ECOM_SokxayPLUS_SETTLE",
  };
  const clauses = ["b.BANK_ACCT = :p_acct", "b.TXN_TYPE LIKE :p_txn_type"];
  if (drawFrom) {
    clauses.push("a.DRAW_ID >= :p_draw_from");
    binds.p_draw_from = drawFrom;
  }
  if (drawTo) {
    clauses.push("a.DRAW_ID <= :p_draw_to");
    binds.p_draw_to = drawTo;
  }
  if (dateFrom) {
    clauses.push("a.DRAW_DATE >= TO_DATE(:p_date_from, 'YYYY-MM-DD')");
    binds.p_date_from = dateFrom;
  }
  if (dateTo) {
    clauses.push("a.DRAW_DATE < TO_DATE(:p_date_to, 'YYYY-MM-DD') + 1");
    binds.p_date_to = dateTo;
  }

  const whereClause = clauses.length ? `WHERE ${clauses.join(" AND ")}` : "";

  const sql = `
    SELECT
      CASE GROUPING(a.DRAW_ID) WHEN 1 THEN NULL ELSE TO_CHAR(MAX(a.DRAW_DATE), 'DD/MM/YYYY') END AS DRAW_DATE,
      CASE GROUPING(a.DRAW_ID) WHEN 1 THEN NULL ELSE TO_CHAR(a.DRAW_ID) END                      AS DRAW_ID,
      TO_CHAR(SUM(a.TOTALSALE),   'FM9,999,999,999,990.00') AS TOTALSALE,
      TO_CHAR(SUM(a.PAY_BCELONE), 'FM9,999,999,999,990.00') AS PAY_ONE,
      TO_CHAR(SUM(a.PAY_POINT),   'FM9,999,999,999,990.00') AS POINT_SALE,
      TO_CHAR(CASE GROUPING(a.DRAW_ID) WHEN 1 THEN SUM(b.BANK_CR) ELSE MAX(b.BANK_CR) END, 'FM9,999,999,999,990.00') AS REAL_STMT,
      TO_CHAR(SUM(a.PAY_BCELONE) - SUM(a.PAY_POINT), 'FM9,999,999,999,990.00') AS DISCUSPOINT,
      TO_CHAR(ROUND(((SUM(a.PAY_BCELONE)) * 0.0135) * 2, 0) / 2, 'FM9,999,999,999,990.00') AS ONEPOINTTHREEPERCENT,
      TO_CHAR(SUM(a.PAY_BCELONE) - (ROUND(((SUM(a.PAY_BCELONE)) * 0.0135) * 2, 0) / 2), 'FM9,999,999,999,990.00') AS DISCUSPERCENT,
      TO_CHAR(
        (SUM(a.PAY_BCELONE) - (ROUND(((SUM(a.PAY_BCELONE)) * 0.0135) * 2, 0) / 2))
        - CASE GROUPING(a.DRAW_ID) WHEN 1 THEN SUM(b.BANK_CR) ELSE MAX(b.BANK_CR) END,
        'FM9,999,999,999,990.00'
      ) AS DIFF
    FROM  ${VIEWS.BCEL_ONEPAY} a
    INNER JOIN ${VIEWS.BCEL_STMT} b ON TO_CHAR(a.DRAW_ID) = b.DRAWID
    ${whereClause}
    GROUP BY ROLLUP(a.DRAW_ID, b.BANK_CR, a.DRAW_DATE)
    HAVING (GROUPING(a.DRAW_ID)=0 AND GROUPING(b.BANK_CR)=0 AND GROUPING(a.DRAW_DATE)=0) OR GROUPING(a.DRAW_ID)=1
    ORDER BY GROUPING(a.DRAW_ID), a.DRAW_ID ASC`;

  const result = await conn.execute(sql, binds, OPT_OBJ);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return NextResponse.json({
    rows: (result.rows ?? []).map((r: any) => ({
      DRAW_DATE: r.DRAW_DATE != null ? String(r.DRAW_DATE) : null,
      DRAW_ID: r.DRAW_ID != null ? String(r.DRAW_ID) : "",
      TOTALSALE: r.TOTALSALE ?? "0.00",
      PAY_ONE: r.PAY_ONE ?? "0.00",
      POINT_SALE: r.POINT_SALE ?? "0.00",
      REAL_STMT: r.REAL_STMT ?? "0.00",
      DISCUSPOINT: r.DISCUSPOINT ?? "0.00",
      ONEPOINTTHREEPERCENT: r.ONEPOINTTHREEPERCENT ?? "0.00",
      DISCUSPERCENT: r.DISCUSPERCENT ?? "0.00",
      DIFF: r.DIFF ?? "0.00",
    })),
  });
}

export async function handleSellChannelByDraw(
  conn: Conn,
  OPT_OBJ: OPT,
  params: URLSearchParams,
) {
  const drawFrom = params.get("draw_from") ?? "";
  const drawTo = params.get("draw_to") ?? "";
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const binds: Record<string, any> = {};
  const whereClauses = [
    "LB.STATUS = 'ACTIVE'",
    "TRUNC(LU.END_DATE) <> TO_DATE('2026-02-19', 'YYYY-MM-DD')",
    "TRUNC(LU.END_DATE) <> TO_DATE('2026-05-24', 'YYYY-MM-DD')",
  ];
  if (drawFrom) {
    whereClauses.push("TO_NUMBER(LB.DRAWID) >= :drawFrom");
    binds.drawFrom = Number(drawFrom);
  }
  if (drawTo) {
    whereClauses.push("TO_NUMBER(LB.DRAWID) <= :drawTo");
    binds.drawTo = Number(drawTo);
  }
  const WHERE_LB = whereClauses.join(" AND ");

  const sql = `
    SELECT LB.DRAWID, TO_CHAR(MIN(LB.DRAW_DATE), 'DD/MM/YYYY') AS DRAW_DATE,
      COUNT(LB.BILLNUMBER) AS TOTAL_BILLS_ALL, SUM(LB.TOTALSALE) AS TOTAL_SALE_ALL,
      COUNT(CASE WHEN LB.DEALERID = '080821001APP' THEN LB.BILLNUMBER END) AS TOTAL_BILLS_APP,
      SUM(CASE WHEN LB.DEALERID = '080821001APP' THEN LB.TOTALSALE ELSE 0 END) AS TOTAL_SALE_APP,
      COUNT(CASE WHEN LB.DEALERID = '080821001APP' AND LENGTH(LB.CLIENTREFNO) < 25 THEN LB.BILLNUMBER END) AS BILLS_APP_SOKXAY,
      SUM(CASE WHEN LB.DEALERID = '080821001APP' AND LENGTH(LB.CLIENTREFNO) < 25 THEN LB.TOTALSALE ELSE 0 END) AS SALE_APP_SOKXAY,
      COUNT(CASE WHEN LB.DEALERID = '080821001APP' AND LENGTH(LB.CLIENTREFNO) > 24 AND LB.CLIENTREFNO LIKE 'SCN2%' THEN LB.BILLNUMBER END) AS BILLS_APP_SCN,
      SUM(CASE WHEN LB.DEALERID = '080821001APP' AND LENGTH(LB.CLIENTREFNO) > 24 AND LB.CLIENTREFNO LIKE 'SCN2%' THEN LB.TOTALSALE ELSE 0 END) AS SALE_APP_SCN,
      COUNT(CASE WHEN LB.DEALERID = '080821001APP' THEN LB.BILLNUMBER END) - COUNT(CASE WHEN LB.DEALERID = '080821001APP' AND LENGTH(LB.CLIENTREFNO) < 25 THEN LB.BILLNUMBER END) - COUNT(CASE WHEN LB.DEALERID = '080821001APP' AND LENGTH(LB.CLIENTREFNO) > 24 AND LB.CLIENTREFNO LIKE 'SCN2%' THEN LB.BILLNUMBER END) AS DIFF_BILLS_APP,
      SUM(CASE WHEN LB.DEALERID = '080821001APP' THEN LB.TOTALSALE ELSE 0 END) - SUM(CASE WHEN LB.DEALERID = '080821001APP' AND LENGTH(LB.CLIENTREFNO) < 25 THEN LB.TOTALSALE ELSE 0 END) - SUM(CASE WHEN LB.DEALERID = '080821001APP' AND LENGTH(LB.CLIENTREFNO) > 24 AND LB.CLIENTREFNO LIKE 'SCN2%' THEN LB.TOTALSALE ELSE 0 END) AS DIFF_SALE_APP,
      COUNT(CASE WHEN LB.DEALERID <> '080821001APP' THEN LB.BILLNUMBER END) AS TOTAL_BILLS_POS,
      SUM(CASE WHEN LB.DEALERID <> '080821001APP' THEN LB.TOTALSALE ELSE 0 END) AS TOTAL_SALE_POS,
      COUNT(CASE WHEN LB.DEALERID <> '080821001APP' AND LU.POS_OWNER_PAYMENT = 'POS-TouBee' THEN LB.BILLNUMBER END) AS BILLS_POS_TOUBEE,
      SUM(CASE WHEN LB.DEALERID <> '080821001APP' AND LU.POS_OWNER_PAYMENT = 'POS-TouBee' THEN LB.TOTALSALE ELSE 0 END) AS SALE_POS_TOUBEE,
      COUNT(CASE WHEN LB.DEALERID <> '080821001APP' AND LU.POS_OWNER_PAYMENT = 'POS-SCN' THEN LB.BILLNUMBER END) AS BILLS_POS_SCN,
      SUM(CASE WHEN LB.DEALERID <> '080821001APP' AND LU.POS_OWNER_PAYMENT = 'POS-SCN' THEN LB.TOTALSALE ELSE 0 END) AS SALE_POS_SCN,
      COUNT(CASE WHEN LB.DEALERID <> '080821001APP' THEN LB.BILLNUMBER END) - COUNT(CASE WHEN LB.DEALERID <> '080821001APP' AND LU.POS_OWNER_PAYMENT = 'POS-TouBee' THEN LB.BILLNUMBER END) - COUNT(CASE WHEN LB.DEALERID <> '080821001APP' AND LU.POS_OWNER_PAYMENT = 'POS-SCN' THEN LB.BILLNUMBER END) AS DIFF_BILLS_POS,
      SUM(CASE WHEN LB.DEALERID <> '080821001APP' THEN LB.TOTALSALE ELSE 0 END) - SUM(CASE WHEN LB.DEALERID <> '080821001APP' AND LU.POS_OWNER_PAYMENT = 'POS-TouBee' THEN LB.TOTALSALE ELSE 0 END) - SUM(CASE WHEN LB.DEALERID <> '080821001APP' AND LU.POS_OWNER_PAYMENT = 'POS-SCN' THEN LB.TOTALSALE ELSE 0 END) AS DIFF_SALE_POS,
      COUNT(LB.BILLNUMBER) - COUNT(CASE WHEN LB.DEALERID = '080821001APP' AND LENGTH(LB.CLIENTREFNO) < 25 THEN LB.BILLNUMBER END) - COUNT(CASE WHEN LB.DEALERID = '080821001APP' AND LENGTH(LB.CLIENTREFNO) > 24 AND LB.CLIENTREFNO LIKE 'SCN2%' THEN LB.BILLNUMBER END) - COUNT(CASE WHEN LB.DEALERID <> '080821001APP' AND LU.POS_OWNER_PAYMENT = 'POS-TouBee' THEN LB.BILLNUMBER END) - COUNT(CASE WHEN LB.DEALERID <> '080821001APP' AND LU.POS_OWNER_PAYMENT = 'POS-SCN' THEN LB.BILLNUMBER END) AS DIFF_BILLS_ALL,
      SUM(LB.TOTALSALE) - SUM(CASE WHEN LB.DEALERID = '080821001APP' AND LENGTH(LB.CLIENTREFNO) < 25 THEN LB.TOTALSALE ELSE 0 END) - SUM(CASE WHEN LB.DEALERID = '080821001APP' AND LENGTH(LB.CLIENTREFNO) > 24 AND LB.CLIENTREFNO LIKE 'SCN2%' THEN LB.TOTALSALE ELSE 0 END) - SUM(CASE WHEN LB.DEALERID <> '080821001APP' AND LU.POS_OWNER_PAYMENT = 'POS-TouBee' THEN LB.TOTALSALE ELSE 0 END) - SUM(CASE WHEN LB.DEALERID <> '080821001APP' AND LU.POS_OWNER_PAYMENT = 'POS-SCN' THEN LB.TOTALSALE ELSE 0 END) AS DIFF_SALE_ALL
    FROM ${VIEWS.LOTLINK_BILL} LB
    LEFT JOIN ECOMMERCE2026.LOTLINK_UNIT LU ON LB.UNITID = LU.UNIT_ID
    WHERE ${WHERE_LB}
    GROUP BY LB.DRAWID
    ORDER BY TO_NUMBER(LB.DRAWID) ASC`;

  const result = await conn.execute(sql, binds, {
    ...OPT_OBJ,
    fetchArraySize: 500,
  });
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return NextResponse.json({
    rows: (result.rows ?? []).map((r: any) => ({
      DRAWID: String(r.DRAWID ?? ""),
      DRAW_DATE: String(r.DRAW_DATE ?? ""),
      TOTAL_BILLS_ALL: Number(r.TOTAL_BILLS_ALL ?? 0),
      TOTAL_SALE_ALL: Number(r.TOTAL_SALE_ALL ?? 0),
      TOTAL_BILLS_APP: Number(r.TOTAL_BILLS_APP ?? 0),
      TOTAL_SALE_APP: Number(r.TOTAL_SALE_APP ?? 0),
      BILLS_APP_SOKXAY: Number(r.BILLS_APP_SOKXAY ?? 0),
      SALE_APP_SOKXAY: Number(r.SALE_APP_SOKXAY ?? 0),
      BILLS_APP_SCN: Number(r.BILLS_APP_SCN ?? 0),
      SALE_APP_SCN: Number(r.SALE_APP_SCN ?? 0),
      DIFF_BILLS_APP: Number(r.DIFF_BILLS_APP ?? 0),
      DIFF_SALE_APP: Number(r.DIFF_SALE_APP ?? 0),
      TOTAL_BILLS_POS: Number(r.TOTAL_BILLS_POS ?? 0),
      TOTAL_SALE_POS: Number(r.TOTAL_SALE_POS ?? 0),
      BILLS_POS_TOUBEE: Number(r.BILLS_POS_TOUBEE ?? 0),
      SALE_POS_TOUBEE: Number(r.SALE_POS_TOUBEE ?? 0),
      BILLS_POS_SCN: Number(r.BILLS_POS_SCN ?? 0),
      SALE_POS_SCN: Number(r.SALE_POS_SCN ?? 0),
      DIFF_BILLS_POS: Number(r.DIFF_BILLS_POS ?? 0),
      DIFF_SALE_POS: Number(r.DIFF_SALE_POS ?? 0),
      DIFF_BILLS_ALL: Number(r.DIFF_BILLS_ALL ?? 0),
      DIFF_SALE_ALL: Number(r.DIFF_SALE_ALL ?? 0),
    })),
  });
}

export async function handleSellChannelByMonth(
  conn: Conn,
  OPT_OBJ: OPT,
  params: URLSearchParams,
) {
  const monthFrom = params.get("month_from") ?? "";
  const monthTo = params.get("month_to") ?? "";
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const binds: Record<string, any> = {};
  const whereClauses = ["STATUS = 'ACTIVE'"];
  const whereClausesLB = [
    "LB.STATUS = 'ACTIVE'",
    "TRUNC(LU.END_DATE) <> TO_DATE('2026-02-19', 'YYYY-MM-DD')",
    "TRUNC(LU.END_DATE) <> TO_DATE('2026-05-24', 'YYYY-MM-DD')",
  ];
  if (monthFrom) {
    whereClauses.push("TO_CHAR(DRAW_DATE,'YYYY-MM') >= :monthFrom");
    whereClausesLB.push("TO_CHAR(LB.DRAW_DATE,'YYYY-MM') >= :monthFrom");
    binds.monthFrom = monthFrom;
  }
  if (monthTo) {
    whereClauses.push("TO_CHAR(DRAW_DATE,'YYYY-MM') <= :monthTo");
    whereClausesLB.push("TO_CHAR(LB.DRAW_DATE,'YYYY-MM') <= :monthTo");
    binds.monthTo = monthTo;
  }
  const WHERE = whereClauses.join(" AND ");
  const WHERE_LB = whereClausesLB.join(" AND ");

  const sql = `
    SELECT A.SALE_MONTH,
      NVL(A.TOTAL_BILLS_ALL,0) AS TOTAL_BILLS_ALL, NVL(A.TOTAL_SALE_ALL,0) AS TOTAL_SALE_ALL,
      NVL(A.TOTAL_BILLS_APP,0) AS TOTAL_BILLS_APP, NVL(A.TOTAL_SALE_APP,0) AS TOTAL_SALE_APP,
      NVL(B.BILLS_APP_SOKXAY,0) AS BILLS_APP_SOKXAY, NVL(B.SALE_APP_SOKXAY,0) AS SALE_APP_SOKXAY,
      NVL(B.BILLS_APP_SCN,0) AS BILLS_APP_SCN, NVL(B.SALE_APP_SCN,0) AS SALE_APP_SCN,
      NVL(A.TOTAL_BILLS_APP,0)-(NVL(B.BILLS_APP_SOKXAY,0)+NVL(B.BILLS_APP_SCN,0)) AS DIFF_BILLS_APP,
      NVL(A.TOTAL_SALE_APP,0)-(NVL(B.SALE_APP_SOKXAY,0)+NVL(B.SALE_APP_SCN,0)) AS DIFF_SALE_APP,
      NVL(A.TOTAL_BILLS_POS,0) AS TOTAL_BILLS_POS, NVL(A.TOTAL_SALE_POS,0) AS TOTAL_SALE_POS,
      NVL(B.BILLS_POS_TOUBEE,0) AS BILLS_POS_TOUBEE, NVL(B.SALE_POS_TOUBEE,0) AS SALE_POS_TOUBEE,
      NVL(B.BILLS_POS_SCN,0) AS BILLS_POS_SCN, NVL(B.SALE_POS_SCN,0) AS SALE_POS_SCN,
      NVL(A.TOTAL_BILLS_POS,0)-(NVL(B.BILLS_POS_TOUBEE,0)+NVL(B.BILLS_POS_SCN,0)) AS DIFF_BILLS_POS,
      NVL(A.TOTAL_SALE_POS,0)-(NVL(B.SALE_POS_TOUBEE,0)+NVL(B.SALE_POS_SCN,0)) AS DIFF_SALE_POS,
      NVL(A.TOTAL_BILLS_ALL,0)-(NVL(B.BILLS_APP_SOKXAY,0)+NVL(B.BILLS_APP_SCN,0)+NVL(B.BILLS_POS_TOUBEE,0)+NVL(B.BILLS_POS_SCN,0)) AS DIFF_BILLS_ALL,
      NVL(A.TOTAL_SALE_ALL,0)-(NVL(B.SALE_APP_SOKXAY,0)+NVL(B.SALE_APP_SCN,0)+NVL(B.SALE_POS_TOUBEE,0)+NVL(B.SALE_POS_SCN,0)) AS DIFF_SALE_ALL
    FROM (
      SELECT TO_CHAR(DRAW_DATE,'YYYY-MM') AS SALE_MONTH,
             COUNT(BILLNUMBER) AS TOTAL_BILLS_ALL, SUM(TOTALSALE) AS TOTAL_SALE_ALL,
             COUNT(CASE WHEN DEALERID = '080821001APP' THEN BILLNUMBER END) AS TOTAL_BILLS_APP,
             SUM(CASE WHEN DEALERID = '080821001APP' THEN TOTALSALE ELSE 0 END) AS TOTAL_SALE_APP,
             COUNT(CASE WHEN DEALERID <> '080821001APP' THEN BILLNUMBER END) AS TOTAL_BILLS_POS,
             SUM(CASE WHEN DEALERID <> '080821001APP' THEN TOTALSALE ELSE 0 END) AS TOTAL_SALE_POS
      FROM   ${VIEWS.LOTLINK_BILL}
      WHERE  ${WHERE}
      GROUP  BY TO_CHAR(DRAW_DATE,'YYYY-MM')
    ) A
    LEFT JOIN (
      SELECT TO_CHAR(LB.DRAW_DATE,'YYYY-MM') AS SALE_MONTH,
        COUNT(CASE WHEN LB.DEALERID='080821001APP' AND LENGTH(LB.CLIENTREFNO)<25 THEN LB.BILLNUMBER END) AS BILLS_APP_SOKXAY,
        SUM(CASE WHEN LB.DEALERID='080821001APP' AND LENGTH(LB.CLIENTREFNO)<25 THEN LB.TOTALSALE ELSE 0 END) AS SALE_APP_SOKXAY,
        COUNT(CASE WHEN LB.DEALERID='080821001APP' AND LENGTH(LB.CLIENTREFNO)>24 AND LB.CLIENTREFNO LIKE 'SCN2%' THEN LB.BILLNUMBER END) AS BILLS_APP_SCN,
        SUM(CASE WHEN LB.DEALERID='080821001APP' AND LENGTH(LB.CLIENTREFNO)>24 AND LB.CLIENTREFNO LIKE 'SCN2%' THEN LB.TOTALSALE ELSE 0 END) AS SALE_APP_SCN,
        COUNT(CASE WHEN LB.DEALERID<>'080821001APP' AND LU.POS_OWNER_PAYMENT='POS-TouBee' THEN LB.BILLNUMBER END) AS BILLS_POS_TOUBEE,
        SUM(CASE WHEN LB.DEALERID<>'080821001APP' AND LU.POS_OWNER_PAYMENT='POS-TouBee' THEN LB.TOTALSALE ELSE 0 END) AS SALE_POS_TOUBEE,
        COUNT(CASE WHEN LB.DEALERID<>'080821001APP' AND LU.POS_OWNER_PAYMENT='POS-SCN' THEN LB.BILLNUMBER END) AS BILLS_POS_SCN,
        SUM(CASE WHEN LB.DEALERID<>'080821001APP' AND LU.POS_OWNER_PAYMENT='POS-SCN' THEN LB.TOTALSALE ELSE 0 END) AS SALE_POS_SCN
      FROM   ${VIEWS.LOTLINK_BILL} LB
      LEFT JOIN ECOMMERCE2026.LOTLINK_UNIT LU ON LB.UNITID = LU.UNIT_ID
      WHERE  ${WHERE_LB}
      GROUP  BY TO_CHAR(LB.DRAW_DATE,'YYYY-MM')
    ) B ON A.SALE_MONTH = B.SALE_MONTH
    ORDER BY A.SALE_MONTH ASC`;

  const result = await conn.execute(sql, binds, {
    ...OPT_OBJ,
    fetchArraySize: 200,
  });
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return NextResponse.json({
    rows: (result.rows ?? []).map((r: any) => ({
      SALE_MONTH: String(r.SALE_MONTH ?? ""),
      TOTAL_BILLS_ALL: Number(r.TOTAL_BILLS_ALL ?? 0),
      TOTAL_SALE_ALL: Number(r.TOTAL_SALE_ALL ?? 0),
      TOTAL_BILLS_APP: Number(r.TOTAL_BILLS_APP ?? 0),
      TOTAL_SALE_APP: Number(r.TOTAL_SALE_APP ?? 0),
      BILLS_APP_SOKXAY: Number(r.BILLS_APP_SOKXAY ?? 0),
      SALE_APP_SOKXAY: Number(r.SALE_APP_SOKXAY ?? 0),
      BILLS_APP_SCN: Number(r.BILLS_APP_SCN ?? 0),
      SALE_APP_SCN: Number(r.SALE_APP_SCN ?? 0),
      DIFF_BILLS_APP: Number(r.DIFF_BILLS_APP ?? 0),
      DIFF_SALE_APP: Number(r.DIFF_SALE_APP ?? 0),
      TOTAL_BILLS_POS: Number(r.TOTAL_BILLS_POS ?? 0),
      TOTAL_SALE_POS: Number(r.TOTAL_SALE_POS ?? 0),
      BILLS_POS_TOUBEE: Number(r.BILLS_POS_TOUBEE ?? 0),
      SALE_POS_TOUBEE: Number(r.SALE_POS_TOUBEE ?? 0),
      BILLS_POS_SCN: Number(r.BILLS_POS_SCN ?? 0),
      SALE_POS_SCN: Number(r.SALE_POS_SCN ?? 0),
      DIFF_BILLS_POS: Number(r.DIFF_BILLS_POS ?? 0),
      DIFF_SALE_POS: Number(r.DIFF_SALE_POS ?? 0),
      DIFF_BILLS_ALL: Number(r.DIFF_BILLS_ALL ?? 0),
      DIFF_SALE_ALL: Number(r.DIFF_SALE_ALL ?? 0),
    })),
  });
}
